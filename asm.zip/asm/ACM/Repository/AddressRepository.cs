﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.Repository
{
    public class AddressRepository
    {
        public Address Retrieve(int addressId)
        {
            Address address = new Address(addressId);

            if (addressId == 1)
            {
                address.AddressType = 1;
                address.StreetLine1 = "Otawan";
                address.StreetLine2 = "Otawon";
                address.City = "Nokyo";
                address.State = "Mapan";
                address.Country = "Jaman";
                address.PostalCode = "140";

            }
            return address;
        }

        public IEnumerable<Address> RetreiveByCustomerId(int customerId)
        {
            var addressList = new List<Address>();
            Address address = new Address(1)
            {
                AddressType = 1,
                StreetLine1 = "Otawan",
                StreetLine2 = "Otawon",
                City = "Nokyo",
                State = "Mapan",
                Country = "Jaman",
                PostalCode = "140"
            };
            addressList.Add(address);

            address = new Address(2)
            {
                AddressType = 2,
                StreetLine1 = "Kami",
                StreetLine2 = "Karma",
                City = "Pinokyo",
                State = "Dapan",
                Country = "Jarman",
                PostalCode = "240"
            };
            addressList.Add(address);

            return addressList;
        }

        public bool Save(Address address)
        {
            return true;
        }
    }
}
