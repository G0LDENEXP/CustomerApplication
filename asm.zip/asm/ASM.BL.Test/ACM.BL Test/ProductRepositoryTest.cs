﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ACM;

namespace ASM.BL.Test
{
    [TestClass]
    public class ProductRepositoryTest
    {
        [TestMethod]
        public void RetrieveTest()
        {

            //-- Arrange
            var productRepository = new ProductRepository();
            var expected = new Product(2)
            {
                ProductName = "RAM",
                ProductDescription = "8GB DDR5 Random Access Memory",
                CurrentPrice = 40.0M

            };

            //-- Act
            var actual = productRepository.Retrieve(2);

            //-- Assert
            Assert.AreEqual(expected.ProductName, actual.ProductName);
            Assert.AreEqual(expected.CurrentPrice,  actual.CurrentPrice);
            Assert.AreEqual(expected.ProductDescription, actual.ProductDescription);
        }

        [TestMethod]
        public void SaveTestValid()
        {

            //-- Arrange
            var productRepository = new ProductRepository();
            var updatedProduct = new Product(2)
            {
                CurrentPrice = 40M,
                ProductDescription = "Assorted Size Set of four 8GB DDR4 RAM",
                ProductName = "RAM",
                HasChanges = true

            };

            //-- Act
            var actual = productRepository.Save(updatedProduct);

            //-- Assert
            Assert.AreEqual(true, actual);

        }

        [TestMethod]
        public void SaveTestMissingPrince()
        {
            //-- Arrange
            var productRepository = new ProductRepository();
            var updateProduct = new Product(2)
            {
                CurrentPrice = null,
                ProductDescription = "Assorted Size Set of four 8GB DDR4 RAM",
                ProductName = "RAM",
                HasChanges = true

            };

            //-- Act
            var actual = productRepository.Save(updateProduct);

            //-- Assert
            Assert.AreEqual(false, actual);
        }
    }
}
