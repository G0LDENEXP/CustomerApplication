﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace ASM.BL.Test
{
    [TestClass]
    public class AddressRepositoryTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
