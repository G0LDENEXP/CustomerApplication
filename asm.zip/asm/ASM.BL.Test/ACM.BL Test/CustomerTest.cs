﻿using ACM;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace ASM.BL.Test
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        public void FullNameTestValid()
        {
            //-- Arrange
            Customer customer = new Customer
            {
                FirstName = "Ben",
                LastName = "Bens"
            };
            string expected = "Bens, Ben";

            //-- Act
            string actual = customer.FullName;

            //-- Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FullNameLastNameEmpty()
        {
            //-- Arrange
            Customer customer = new Customer
            {
                
                FirstName = "Ben"
            };
            string expected = "Ben";

            //-- Act
            string actual = customer.FullName;

            //-- Assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void StaticTest()
        {
            //-- Arrange
            Customer c1 = new Customer();
            c1.FirstName = "Ben";
            Customer.InstanceCount += 1;

            var c2 = new Customer();
            c2.FirstName = "Frodo";
            Customer.InstanceCount += 1;

            var c3 = new Customer();
            c3.FirstName = "Rose";
            Customer.InstanceCount += 1;

            //-- Act


            //-- Assert
            Assert.AreEqual(3, Customer.InstanceCount);
        }
        [TestMethod]
        public void ValidateValid()
        {
            //-- Arrange
            Customer customer = new Customer
            {
                //LastName = "Bob",
                EmailAddress = "bob123@mail.me"
            };

            var expected = false;
            //-- Act
            var actual = customer.Validate();

            //-- Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
