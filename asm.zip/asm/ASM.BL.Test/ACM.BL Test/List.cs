﻿using ACM;

namespace ASM.BL.Test
{
    internal class List<T> : System.Collections.Generic.List<Address>
    {
    }
}