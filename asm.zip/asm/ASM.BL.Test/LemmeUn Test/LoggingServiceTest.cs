﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LemmeUncommon;
using ACM;
using System;
using System.Collections.Generic;

namespace ASM.BL.Test.LemmeUn_Test
{
    [TestClass]
    public class LoggingServiceTest
    {
        [TestMethod]
        public void WriteToFileTest()
        {
            //-- Arrange
            var changedItems = new List<ILoggable>();

            var customer = new Customer(1)
            {
                EmailAddress = "bobbobs2@mail.me",
                FirstName = "Bob",
                LastName = "Brown",
                AddressList = null
            };
            changedItems.Add((Address)customer);
            
            var product = new Product(2)
            {
                ProductName = "GTR 777",
                ProductDescription = "GPU graphic card",
                CurrentPrice = 600M
            };
            changedItems.Add(product);

            //-- Act
            LoggingService.WriteToFile(changedItems);
        }
    }
}
