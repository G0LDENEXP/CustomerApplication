﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LemmeUncommon;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ASM.BL.Test
{
    [TestClass]
    public class StringHandlerTest
    {
        [TestMethod]
        public void InsertSpacesTestValid()
        {
            //-- Arrange
            var source = "SonicScrewdriver";
            var expected = "Sonic Screwdriver";
            

            //-- Act
            var actual = source.InsertSpaces();

            //-- Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InsertSpacesWithExistingSpace()
        {
            //-- Arrange
            var source = "Sonic Screwdriver";
            var expected = "Sonic Screwdriver";
            

            //-- Act
            var actual = source.InsertSpaces();

            //-- Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
